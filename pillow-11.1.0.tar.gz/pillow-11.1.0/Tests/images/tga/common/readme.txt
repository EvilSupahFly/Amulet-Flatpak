Images in this directory were created with GIMP.

TGAs have names in the following format:

  {width}x{height}_{mode}_{origin}_{compression}.tga

Where:
  mode is PIL mode in lower case (L, P, RGB, etc.)
  origin:
    "bl" - bottom left
    "tl" - top left
  compression is either "raw" or "rle"
