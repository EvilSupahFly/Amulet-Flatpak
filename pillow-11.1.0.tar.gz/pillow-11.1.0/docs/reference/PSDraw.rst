.. py:module:: PIL.PSDraw
.. py:currentmodule:: PIL.PSDraw

:py:mod:`~PIL.PSDraw` Module
============================

The :py:mod:`~PIL.PSDraw` module provides simple print support for PostScript
printers. You can print text, graphics and images through this module.

.. autoclass:: PIL.PSDraw.PSDraw
    :members:
