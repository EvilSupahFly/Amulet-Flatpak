Installation
============

.. toctree::
  :maxdepth: 2

  basic-installation
  python-support
  platform-support
  building-from-source
