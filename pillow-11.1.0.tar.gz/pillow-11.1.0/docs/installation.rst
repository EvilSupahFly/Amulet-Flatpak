:orphan:

Installation
============

Basic Installation
------------------

.. Note:: This section has moved to :ref:`basic-installation`. Please update references accordingly.

Python Support
--------------

.. Note:: This section has moved to :ref:`python-support`. Please update references accordingly.

Platform Support
----------------

.. Note:: This section has moved to :ref:`platform-support`. Please update references accordingly.

Building From Source
--------------------

.. Note:: This section has moved to :ref:`building-from-source`. Please update references accordingly.

Old Versions
------------

.. Note:: This section has moved to :ref:`old-versions`. Please update references accordingly.
