from typing import Union
from numpy import integer

Int = Union[int, integer]
