from PyInstaller.utils.hooks import collect_data_files, collect_submodules

datas = collect_data_files("minecraft_model_reader")
hiddenimports = collect_submodules("minecraft_model_reader")
