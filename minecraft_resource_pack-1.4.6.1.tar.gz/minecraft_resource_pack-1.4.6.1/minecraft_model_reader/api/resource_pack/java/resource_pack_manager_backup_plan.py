import os
import json
import traceback
import logging

log = logging.getLogger(__name__)

# ... (all existing imports and class definitions unchanged)

class JavaResourcePackManager(ResourcePackManager):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Backups for java_vanilla_fix only
        self._textures_backup = {}
        self._models_backup = {}

    def _load_iter(self):
        log.debug("[LOAD_ITER] Beginning _load_iter()")
        pack_count = len(self._packs)
        log.debug(f"pack_count = {pack_count}")

        for pack in self._packs:
            log.debug(f"[PACK] Processing pack: {pack}")
            log.debug(f"[PACK ROOT] {pack._root_dir}")

            # Identify java_vanilla_fix for backup population
            is_java_fix = "java_vanilla_fix" in str(pack._root_dir)

            for key, value in getattr(pack, "_textures", {}).items():
                self._textures[key] = value
                if is_java_fix:
                    self._textures_backup[key] = value

            for key, value in getattr(pack, "_blockstate_models", {}).items():
                self._blockstate_models[key] = value
                if is_java_fix:
                    self._models_backup[key] = value

        log.debug(f"[TEXTURE COUNT - END] _textures contains {len(self._textures)} entries before atlas handoff")

    def get_texture_path(self, namespace: str, relative_path: str) -> str:
        key = (namespace, relative_path)
        if key in self._textures:
            return self._textures[key]

        # Fallback: backup check (java_vanilla_fix only)
        if key in self._textures_backup:
            if relative_path in ("block/water", "block/lava"):
                log.debug(f"[BACKUP HIT - TEXTURE] {relative_path} from backup: {self._textures_backup[key]}")
            return self._textures_backup[key]

        # If still missing, log only water/lava
        if relative_path in ("block/water", "block/lava"):
            log.debug(f"[MISSING TEXTURE] {relative_path} not found in primary or backup.")
        return self.missing_no

    def _get_model(self, block):
        """Existing _get_model with backup fallback & water/lava logging"""
        try:
            namespace = block.namespace
            base_name = block.base_name
            key = (namespace, base_name)

            if key in self._blockstate_models:
                return self._blockstate_models[key]

            # Backup fallback
            if key in self._models_backup:
                if base_name in ("block/water", "block/lava"):
                    log.debug(f"[BACKUP HIT - MODEL] {base_name} from backup.")
                return self._models_backup[key]

            if base_name in ("block/water", "block/lava"):
                log.debug(f"[MISSING MODEL] {base_name} not found in primary or backup.")

        except Exception as e:
            if base_name in ("block/water", "block/lava"):
                log.error(f"[ERROR in _get_model] {base_name}: {e}")
        return self.missing_no
