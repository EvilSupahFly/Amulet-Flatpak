import os
import json
import copy
from typing import Union, Iterable, Iterator, Optional
from PIL import Image
import numpy
import glob
import itertools
import logging
import time, hashlib
import amulet_nbt
import traceback
from minecraft_model_reader.api import Block
from minecraft_model_reader.api.resource_pack import BaseResourcePackManager
from minecraft_model_reader.api.resource_pack.java import JavaResourcePack
from minecraft_model_reader.api.mesh.block.block_mesh import (
    BlockMesh,
    FACE_KEYS,
    Transparency,
)
from minecraft_model_reader.api.mesh.util import rotate_3d
from minecraft_model_reader.api.mesh.block.cube import (
    cube_face_lut,
    uv_rotation_lut,
    tri_face,
)

log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

UselessImageGroups = {
    "colormap",
    "effect",
    "environment",
    "font",
    "gui",
    "map",
    "mob_effect",
    "particle",
}


class JavaResourcePackManager(BaseResourcePackManager[JavaResourcePack]):
    """A class to load and handle the data from the packs.
    Packs are given as a list with the later packs overwriting the earlier ones."""

    def __init__(
        self,
        resource_packs: Union[JavaResourcePack, Iterable[JavaResourcePack]],
        load: bool = True,
    ) -> None:
        super().__init__()
        self._blockstate_files: dict[tuple[str, str], dict] = {}
        self._textures: dict[tuple[str, str], str] = {}
        self._texture_is_transparent: dict[str, tuple[float, bool]] = {}
        self._model_files: dict[tuple[str, str], dict] = {}
        # Backups for java_vanilla_fix only
        self._textures_backup: dict[tuple[str, str], str] = {}
        self._model_files_backup: dict[tuple[str, str], dict] = {}
        if isinstance(resource_packs, Iterable):
            self._packs = list(resource_packs)
        elif isinstance(resource_packs, JavaResourcePack):
            self._packs = [resource_packs]
        else:
            raise Exception(f"Invalid format {resource_packs}")
        try:
            self._epoch = time.perf_counter()
            log.debug(f"[RPM:EPOCH] init_perf_counter={self._epoch:.6f}")
        except Exception as e:
            log.debug(f"[RPM:EPOCH] unable to set epoch: {e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))
        if load:
            for _ in self.reload():
                pass

    def _unload(self) -> None:
        """Clear all loaded resources."""
        super()._unload()
        self._blockstate_files.clear()
        self._textures.clear()
        self._textures_backup.clear()
        self._texture_is_transparent.clear()
        self._model_files.clear()
        self._model_files_backup.clear()

    def _load_iter(self) -> Iterator[float]:
        t0 = time.perf_counter()
        def _dt():
            return f"+{(time.perf_counter() - t0):.6f}s"
        log.debug(f"[RPM:RELOAD] start {_dt()} (since init "+
                  (f"{(t0 - getattr(self, '_epoch', t0)):.6f}s" if hasattr(self,'_epoch') else 'n/a')+
                  ")")
        blockstate_file_paths: dict[tuple[str, str], str] = {}
        model_file_paths: dict[tuple[str, str], str] = {}

        transparency_cache_path = os.path.join(
            os.environ["CACHE_DIR"], "resource_packs", "java", "transparency_cache.json"
        )
        self._load_transparency_cache(transparency_cache_path)

        self._textures[("minecraft", "missing_no")] = self.missing_no
        self._textures_backup[("minecraft", "missing_no")] = self.missing_no

        pack_count = len(self._packs)
        try:
            names = [getattr(p, 'root_dir', '<no-root>') for p in self._packs]
            log.debug(f"[ENUM:PACKS] order={names}")
            log.debug(f"[ENUM:PACKS] order_sha1={hashlib.sha1(''.join(names).encode('utf-8')).hexdigest()}")
        except Exception as e:
            log.debug(f"[ENUM:PACKS] error: {e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))

        for pack_index, pack in enumerate(self._packs):
            # pack_format=2 textures/blocks, textures/items - case sensitive
            # pack_format=3 textures/blocks, textures/items - lower case
            # pack_format=4 textures/block, textures/item
            # pack_format=5 model paths and texture paths are now optionally namespaced

            pack_progress = pack_index / pack_count
            yield pack_progress

            if pack.valid_pack and pack.pack_format >= 2:
                image_paths = glob.glob(
                    os.path.join(
                        glob.escape(pack.root_dir),
                        "assets",
                        "*",  # namespace
                        "textures",
                        "**",
                        "*.png",
                    ),
                    recursive=True,
                )
                image_count = len(image_paths)
                sub_progress = pack_progress
                for image_index, texture_path in enumerate(image_paths):
                    _, namespace, _, *rel_path_list = os.path.normpath(
                        os.path.relpath(texture_path, pack.root_dir)
                    ).split(os.sep)
                    if rel_path_list[0] not in UselessImageGroups:
                        rel_path = "/".join(rel_path_list)[:-4]
                        self._textures[(namespace, rel_path)] = texture_path
                        self._textures_backup[(namespace, rel_path)] = texture_path
                        if (
                            os.stat(texture_path).st_mtime
                            != self._texture_is_transparent.get(texture_path, [0])[0]
                        ):
                            im: Image.Image = Image.open(texture_path)
                            key = (namespace, texture_path)
                            # Primary lookup
                            if key in self._textures:
                                if image_paths in ("block/water", "block/lava"):
                                    log.debug(f"[_load_iter] Now loading {texture_path}")
                                    log.debug(f"[FSENC] {os.fsencode(texture_path)!r}")
                            if im.mode == "RGBA":
                                alpha = numpy.array(im.getchannel("A").getdata())
                                texture_is_transparent = bool(numpy.any(alpha != 255))
                                if key in self._textures:
                                    if image_paths in ("block/water", "block/lava"):
                                        log.debug(f"[_load_iter] Transparency found for {texture_path} - texture successfuly read from disk.")
                            else:
                                texture_is_transparent = False

                            self._texture_is_transparent[texture_path] = (
                                os.stat(texture_path).st_mtime,
                                texture_is_transparent,
                            )
                    yield sub_progress + image_index / (image_count * pack_count * 3)

                blockstate_paths = glob.glob(
                    os.path.join(
                        glob.escape(pack.root_dir),
                        "assets",
                        "*",  # namespace
                        "blockstates",
                        "*.json",
                    )
                )
                blockstate_count = len(blockstate_paths)
                sub_progress = pack_progress + 1 / (pack_count * 3)
                for blockstate_index, blockstate_path in enumerate(blockstate_paths):
                    _, namespace, _, blockstate_file = os.path.normpath(
                        os.path.relpath(blockstate_path, pack.root_dir)
                    ).split(os.sep)
                    blockstate_file_paths[(namespace, blockstate_file[:-5])] = (
                        blockstate_path
                    )
                    yield sub_progress + (blockstate_index) / (
                        blockstate_count * pack_count * 3
                    )

                model_paths = glob.glob(
                    os.path.join(
                        glob.escape(pack.root_dir),
                        "assets",
                        "*",  # namespace
                        "models",
                        "**",
                        "*.json",
                    ),
                    recursive=True,
                )
                model_count = len(model_paths)
                sub_progress = pack_progress + 2 / (pack_count * 3)
                for model_index, model_path in enumerate(model_paths):
                    _, namespace, _, *rel_path_list = os.path.normpath(
                        os.path.relpath(model_path, pack.root_dir)
                    ).split(os.sep)
                    rel_path = "/".join(rel_path_list)[:-5]
                    model_file_paths[(namespace, rel_path.replace(os.sep, "/"))] = (
                        model_path
                    )
                    yield sub_progress + (model_index) / (model_count * pack_count * 3)

        os.makedirs(os.path.dirname(transparency_cache_path), exist_ok=True)
        with open(transparency_cache_path, "w") as f:
            json.dump(self._texture_is_transparent, f)

        for key, path in blockstate_file_paths.items():
            with open(path) as fi:
                try:
                    self._blockstate_files[key] = json.load(fi)
                except json.JSONDecodeError:
                    log.error(f"Failed to parse blockstate file {path}")

        for key, path in model_file_paths.items():
            with open(path) as fi:
                try:
                    self._model_files[key] = json.load(fi)
                    self._model_files_backup[key] = json.load(fi)
                except json.JSONDecodeError:
                    log.error(f"Failed to parse model file file {path}")
        try:
            keys = [(ns, rel) for (ns, rel) in self._textures.keys() if rel in (
                'block/water', 'block/water_flow', 'block/water_still', 'block/water_overlay',
                'block/lava', 'block/lava_flow', 'block/lava_still'
            )]
            vals = {k: self._textures[k] for k in keys}
            bkeys = [(ns, rel) for (ns, rel) in self._textures_backup.keys() if rel in (
                'block/water', 'block/water_flow', 'block/water_still', 'block/water_overlay',
                'block/lava', 'block/lava_flow', 'block/lava_still'
            )]
            bvals = {k: self._textures_backup[k] for k in bkeys}
            def _exists_map(d):
                return {k: (v, os.path.exists(v)) for k, v in d.items()}
            log.debug(f"[SANITY:PRIMARY] { _exists_map(vals) }")
            log.debug(f"[SANITY:BACKUP ] { _exists_map(bvals) }")
        except Exception as e:
            log.debug(f"[SANITY] error: {e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))                    

    @property
    def textures(self) -> tuple[str, ...]:
        """Returns a tuple of all the texture paths in the resource pack."""
        return tuple(self._textures.values())

    def get_texture_path(self, namespace: Optional[str], relative_path: str) -> str:
        """Get the absolute texture path from the namespace and relative_path pair."""
        log.debug(f"[PROBE:TEXTURE] Called with ns={namespace}, rel={relative_path}")
        if namespace is None:
            if relative_path in ("block/water", "block/lava"):
                log.debug(f"[PROBE:TEXTURE] Missing namespace for {relative_path}, using missing_no.")
            return self.missing_no

        key = (namespace, relative_path)

        # Primary lookup
        if key in self._textures:
            if relative_path in ("block/water", "block/lava"):
                log.debug(f"[TEXTURE FOUND - PRIMARY] ns={namespace}, rel={relative_path}, abs={self._textures[key]}")
                abs_path = self._textures[key]
                log.debug(f"[PROBE:ABS_PATH] Using abs_path={abs_path}")
                import hashlib
                h = hashlib.sha1()
                with open(abs_path, "rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
                log.debug(f"[TEXTURE SHA1] {abs_path} = {h.hexdigest()}")

                try:
                    # Quick, zero-ambiguity checks:
                    exists = os.path.exists(abs_path)
                    readable = os.access(abs_path, os.R_OK)
                    st = os.stat(abs_path) if exists else None
                    head = None
                    if exists:
                        with open(abs_path, "rb") as f:
                            head = f.read(16)
                    log.debug(f"[TEXTURE VERIFY:FS] exists={exists} readable={readable} size={(st.st_size if st else 'NA')} head={head!r}")

                    # Pillow sanity (no decoding yet)
                    from PIL import Image
                    with Image.open(abs_path) as im:
                        im.load()   # force decode
                        log.debug(f"[TEXTURE VERIFY:PIL] ok mode={im.mode} size={im.size} format={im.format}")
                except Exception as e:
                    log.error(f"[TEXTURE VERIFY:FAIL] type={type(e).__name__} repr={e!r}", exc_info=True)

            return self._textures[key]

        # Backup lookup
        if key in self._textures_backup:
            if relative_path in ("block/water", "block/lava"):
                log.debug(f"[TEXTURE FOUND - BACKUP] ns={namespace}, rel={relative_path}, abs={self._textures_backup[key]}")
            return self._textures_backup[key]

        if relative_path in ("block/water", "block/lava"):
            log.debug(f"[MISSING TEXTURE] ns={namespace}, rel={relative_path} not found in primary or backup.")

        log.debug(f"[MISSING TEXTURE] key={key} not found in primary or backup.\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))

        return self.missing_no
    
    @staticmethod
    def parse_state_val(val: Union[str, bool]) -> list:
        """Convert the json block state format into a consistent format."""
        if isinstance(val, str):
            return [amulet_nbt.TAG_String(v) for v in val.split("|")]
        elif isinstance(val, bool):
            return [
                amulet_nbt.TAG_String("true") if val else amulet_nbt.TAG_String("false")
            ]
        else:
            raise Exception(f"Could not parse state val {val}")

    def _get_model(self, block: Block) -> BlockMesh:
        """Find the model paths for a given block state and load them."""
        log.debug(f"[PROBE:MODEL] ns={block.namespace} name={block.base_name}")
        log.debug(f"[_get_model] Called for block ns={block.namespace}, name={block.base_name}, props={block.properties}")
        log.debug(f"[_get_model] Current model search dirs: {getattr(self, '_search_paths', '<no _search_paths attribute>')}")
        if (block.namespace, block.base_name) in self._blockstate_files:
            blockstate: dict = self._blockstate_files[(block.namespace, block.base_name)]
            log.debug(f"[_get_model] Found blockstate entry with keys: {list(blockstate.keys())}")
            if "variants" in blockstate:
                for variant in blockstate["variants"]:
                    log.debug(f"[_get_model] Checking variant '{variant}'")
                    if variant == "":
                        try:
                            model = blockstate["variants"][variant]
                            log.debug(f"[_get_model] Loading empty variant model: {model}")
                            return self._load_blockstate_model(model)
                        except Exception as e:
                            log.error(f"Failed to load block model {model}\n{e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))
                    else:
                        properties_match = Block.properties_regex.finditer(f",{variant}")
                        if all(
                            block.properties.get(
                                match.group("name"),
                                amulet_nbt.TAG_String(match.group("value")),
                            ).py_data == match.group("value")
                            for match in properties_match
                        ):
                            try:
                                model = blockstate["variants"][variant]
                                log.debug(f"[_get_model] Loading matching variant model: {model}")
                                return self._load_blockstate_model(model)
                            #except Exception as e:
                            #    log.error(f"Failed to load block model {model}\n{e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))
                            except Exception as e:
                                log.error(
                                    "[MODEL BUILD FAIL] model=%s type=%s repr=%r",
                                    model, type(e).__name__, e, exc_info=True
                                )
                                # Optional: dump any texture paths that were resolved for this model
                                try:
                                    tex = model.get("textures", {})
                                    for k, v in tex.items():
                                        # v may be "minecraft:block/water" – resolve it to a path if you can
                                        ns, rel = (v.split(":", 1) + ["minecraft"])[:2][::-1] if ":" in v else ("minecraft", v)
                                        try:
                                            abs_tex = self.get_texture_path(ns, rel)
                                        except Exception as te:
                                            abs_tex = f"<resolve-fail:{type(te).__name__}:{te!r}>"
                                        log.debug(f"[MODEL TEXTURE] key={k} val={v} path={abs_tex}")
                                        log.debug(f"[MODEL TEXTURES] model={model.get('textures', {})}")

                                except Exception:
                                    pass

            elif "multipart" in blockstate:
                log.debug(f"[_get_model] Processing multipart blockstate")
                models = []
                for idx, case in enumerate(blockstate["multipart"]):
                    log.debug(f"[_get_model] Case {idx}: {case}")
                    try:
                        if "when" in case:
                            if "OR" in case["when"]:
                                if not any(
                                    all(
                                        block.properties.get(prop, None) in self.parse_state_val(val)
                                        for prop, val in prop_match.items()
                                    )
                                    for prop_match in case["when"]["OR"]
                                ):
                                    continue
                            elif "AND" in case["when"]:
                                if not all(
                                    all(
                                        block.properties.get(prop, None) in self.parse_state_val(val)
                                        for prop, val in prop_match.items()
                                    )
                                    for prop_match in case["when"]["AND"]
                                ):
                                    continue
                            elif not all(
                                block.properties.get(prop, None) in self.parse_state_val(val)
                                for prop, val in case["when"].items()
                            ):
                                continue
                        if "apply" in case:
                            try:
                                log.debug(f"[_get_model] Applying case model: {case['apply']}")
                                models.append(self._load_blockstate_model(case["apply"]))
                            except Exception as e:
                                log.error(f"Failed to load block model for case = {case['apply']}\n{e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))
                    except Exception as e:
                        log.error(f"Failed to parse block state for block = {block}\n{e}\nCall stack:\n" + "".join(traceback.format_stack(limit=20)))
                return BlockMesh.merge(models)
        else:
            log.debug(f"[_get_model] No blockstate entry found for ns={block.namespace}, name={block.base_name}")
        return self.missing_block

    def _load_blockstate_model(
        self, blockstate_value: Union[dict, list[dict]]
    ) -> BlockMesh:
        """Load the model(s) associated with a block state and apply rotations if needed."""
        if isinstance(blockstate_value, list):
            blockstate_value = blockstate_value[0]
        if "model" not in blockstate_value:
            return self.missing_block
        model_path = blockstate_value["model"]
        rotx = int(blockstate_value.get("x", 0) // 90)
        roty = int(blockstate_value.get("y", 0) // 90)
        uvlock = blockstate_value.get("uvlock", False)

        model = copy.deepcopy(self._load_block_model(model_path))

        # TODO: rotate model based on uv_lock
        return model.rotate(rotx, roty)

    def _load_block_model(self, model_path: str) -> BlockMesh:
        """Load the model file associated with the Block and convert to a BlockMesh."""
        log.debug(f"[PROBE:MODEL] Loading model from path: {model_path}")
        # recursively load model files into one dictionary
        java_model = self._recursive_load_block_model(model_path)

        # set up some variables
        texture_dict = {}
        textures = []
        texture_count = 0
        vert_count = {side: 0 for side in FACE_KEYS}
        verts_src: dict[Optional[str], list[numpy.ndarray]] = {
            side: [] for side in FACE_KEYS
        }
        tverts_src: dict[Optional[str], list[numpy.ndarray]] = {
            side: [] for side in FACE_KEYS
        }
        tint_verts_src: dict[Optional[str], list[float]] = {
            side: [] for side in FACE_KEYS
        }
        faces_src: dict[Optional[str], list[numpy.ndarray]] = {
            side: [] for side in FACE_KEYS
        }

        texture_indexes_src: dict[Optional[str], list[int]] = {
            side: [] for side in FACE_KEYS
        }
        transparent = Transparency.Partial

        if set(java_model.get("textures", {})).difference(
            {"particle"}
        ) and not java_model.get("elements"):
            return self.missing_block

        for element in java_model.get("elements", {}):
            # iterate through elements (one cube per element)
            element_faces = element.get("faces", {})

            opaque_face_count = 0
            if (
                transparent
                and "rotation" not in element
                and element.get("to", [16, 16, 16]) == [16, 16, 16]
                and element.get("from", [0, 0, 0]) == [0, 0, 0]
                and len(element_faces) >= 6
            ):
                # if the block is not yet defined as a solid block
                # and this element is a full size element
                # check if the texture is opaque
                transparent = Transparency.FullTranslucent
                check_faces = True
            else:
                check_faces = False

            # lower and upper box coordinates
            corners = numpy.sort(
                numpy.array(
                    [element.get("to", [16, 16, 16]), element.get("from", [0, 0, 0])],
                    float,
                )
                / 16,
                0,
            )

            # vertex coordinates of the box
            box_coordinates = numpy.array(
                list(itertools.product(corners[:, 0], corners[:, 1], corners[:, 2]))
            )

            for face_dir in element_faces:
                if face_dir in cube_face_lut:
                    # get the cull direction. If there is an opaque block in this direction then cull this face
                    cull_dir = element_faces[face_dir].get("cullface", None)
                    if cull_dir not in FACE_KEYS:
                        cull_dir = None

                    # get the relative texture path for the texture used
                    texture_relative_path = element_faces[face_dir].get("texture", None)
                    while isinstance(
                        texture_relative_path, str
                    ) and texture_relative_path.startswith("#"):
                        texture_relative_path = java_model["textures"].get(
                            texture_relative_path[1:], None
                        )
                    texture_path_list = texture_relative_path.split(":", 1)
                    if len(texture_path_list) == 2:
                        namespace, texture_relative_path = texture_path_list
                    else:
                        namespace = "minecraft"

                    texture_path = self.get_texture_path(
                        namespace, texture_relative_path
                    )

                    if check_faces:
                        if self._texture_is_transparent[texture_path][1]:
                            check_faces = False
                        else:
                            opaque_face_count += 1

                    # get the texture
                    if texture_relative_path not in texture_dict:
                        texture_dict[texture_relative_path] = texture_count
                        textures.append(texture_path)
                        texture_count += 1

                    # texture index for the face
                    texture_index = texture_dict[texture_relative_path]

                    # get the uv values for each vertex
                    # TODO: get the uv based on box location if not defined
                    texture_uv = (
                        numpy.array(
                            element_faces[face_dir].get("uv", [0, 0, 16, 16]),
                            float,
                        )
                        / 16
                    )
                    texture_rotation = element_faces[face_dir].get("rotation", 0)
                    uv_slice = (
                        uv_rotation_lut[2 * int(texture_rotation / 90) :]
                        + uv_rotation_lut[: 2 * int(texture_rotation / 90)]
                    )

                    # merge the vertex coordinates and texture coordinates
                    face_verts = box_coordinates[cube_face_lut[face_dir]]
                    if "rotation" in element:
                        rotation = element["rotation"]
                        origin = [r / 16 for r in rotation.get("origin", [8, 8, 8])]
                        angle = rotation.get("angle", 0)
                        axis = rotation.get("axis", "x")
                        angles = [0, 0, 0]
                        if axis == "x":
                            angles[0] = -angle
                        elif axis == "y":
                            angles[1] = -angle
                        elif axis == "z":
                            angles[2] = -angle
                        face_verts = rotate_3d(face_verts, *angles, *origin)

                    verts_src[cull_dir].append(
                        face_verts
                    )  # vertex coordinates for this face

                    tverts_src[cull_dir].append(
                        texture_uv[uv_slice].reshape((-1, 2))  # texture vertices
                    )
                    if "tintindex" in element_faces[face_dir]:
                        tint_verts_src[cull_dir] += [
                            0,
                            1,
                            0,
                        ] * 4  # TODO: set this up for each supported block
                    else:
                        tint_verts_src[cull_dir] += [1, 1, 1] * 4

                    # merge the face indexes and texture index
                    face_table = tri_face + vert_count[cull_dir]
                    texture_indexes_src[cull_dir] += [texture_index, texture_index]

                    # faces stored under cull direction because this is the criteria to render them or not
                    faces_src[cull_dir].append(face_table)

                    vert_count[cull_dir] += 4

            if opaque_face_count == 6:
                transparent = Transparency.FullOpaque

        verts: dict[Optional[str], numpy.ndarray] = {}
        tverts: dict[Optional[str], numpy.ndarray] = {}
        tint_verts: dict[Optional[str], numpy.ndarray] = {}
        faces: dict[Optional[str], numpy.ndarray] = {}
        texture_indexes: dict[Optional[str], numpy.ndarray] = {}

        for cull_dir in FACE_KEYS:
            face_array = faces_src[cull_dir]
            if len(face_array) > 0:
                faces[cull_dir] = numpy.concatenate(face_array, axis=None)
                tint_verts[cull_dir] = numpy.concatenate(
                    tint_verts_src[cull_dir], axis=None
                )
                verts[cull_dir] = numpy.concatenate(verts_src[cull_dir], axis=None)
                tverts[cull_dir] = numpy.concatenate(tverts_src[cull_dir], axis=None)
                texture_indexes[cull_dir] = numpy.array(
                    texture_indexes_src[cull_dir], dtype=numpy.uint32
                )

        return BlockMesh(
            3,
            verts,
            tverts,
            tint_verts,
            faces,
            texture_indexes,
            tuple(textures),
            transparent,
        )

    def _recursive_load_block_model(self, model_path: str) -> dict:
        """Load a model json file and recursively load and merge the parent entries into one json file."""
        log.debug(f"[ENTER] _recursive_load_block_model(model_path={model_path})")
        model_path_list = model_path.split(":", 1)
        if len(model_path_list) == 2:
            namespace, model_path = model_path_list
        else:
            namespace = "minecraft"
        log.debug(f"  Parsed namespace={namespace}, model_path={model_path}")

        if (namespace, model_path) in self._model_files:
            log.debug(f"  Found model in _model_files: key=({namespace}, {model_path})")
            model = self._model_files[(namespace, model_path)]

            if "parent" in model:
                log.debug(f"  Model has parent: {model['parent']}")
                parent_model = self._recursive_load_block_model(model["parent"])
            else:
                parent_model = {}

            if "textures" in model:
                if "textures" not in parent_model:
                    parent_model["textures"] = {}
                for key, val in model["textures"].items():
                    parent_model["textures"][key] = val
                log.debug(f"  Merged textures for model {model_path}: {model['textures'].keys()}")

            if "elements" in model:
                parent_model["elements"] = model["elements"]
                log.debug(f"  Merged elements for model {model_path}")

            log.debug(f"[EXIT] _recursive_load_block_model returning merged model for {model_path}")
            return parent_model

        log.debug(f"  Model ({namespace}, {model_path}) not found in _model_files. Returning empty.")
        return 