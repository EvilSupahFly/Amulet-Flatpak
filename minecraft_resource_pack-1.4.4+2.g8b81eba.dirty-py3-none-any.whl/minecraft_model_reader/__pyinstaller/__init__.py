def get_hook_dirs() -> list[str]:
    return __path__
