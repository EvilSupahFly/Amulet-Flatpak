
                      hotspot_x = image.GetOptionInt(wx.IMAGE_OPTION_CUR_HOTSPOT_X)
                      hotspot_y = image.GetOptionInt(wx.IMAGE_OPTION_CUR_HOTSPOT_Y)
