    
    text/html
    text/plain
    image/*
