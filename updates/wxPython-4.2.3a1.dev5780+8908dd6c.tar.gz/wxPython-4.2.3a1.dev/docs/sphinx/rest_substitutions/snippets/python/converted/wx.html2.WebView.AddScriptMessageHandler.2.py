    
    # Send sample message body
    window.wx_msg.postMessage('This is a message body')
