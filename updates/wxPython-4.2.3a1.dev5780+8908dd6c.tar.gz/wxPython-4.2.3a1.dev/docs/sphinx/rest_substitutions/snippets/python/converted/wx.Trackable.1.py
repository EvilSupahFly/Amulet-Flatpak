
# This class is not expected to be used from Python.
