
                box = wx.StaticBox(panel, wx.ID_ANY, "StaticBox")

                text = wx.StaticText(panel, wx.ID_ANY, "This window is a child of the panel")

                # Other code...
