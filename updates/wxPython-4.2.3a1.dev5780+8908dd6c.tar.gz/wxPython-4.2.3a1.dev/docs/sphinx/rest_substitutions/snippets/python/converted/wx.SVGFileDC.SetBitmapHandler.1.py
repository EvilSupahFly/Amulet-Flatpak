    
    mySVGFileDC.SetBitmapHandler(wx.SVGBitmapEmbedHandler())
