
     self.GetEventHandler().ProcessEvent(event)
