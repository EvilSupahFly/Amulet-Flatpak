
     wx.Size(0, 0)
