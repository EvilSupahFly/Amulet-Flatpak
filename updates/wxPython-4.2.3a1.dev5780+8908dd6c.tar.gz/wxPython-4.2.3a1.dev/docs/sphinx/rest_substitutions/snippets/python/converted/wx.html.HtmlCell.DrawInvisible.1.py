

        dc.DrawText("hello", x + cell.PosX, y + cell.PosY)
