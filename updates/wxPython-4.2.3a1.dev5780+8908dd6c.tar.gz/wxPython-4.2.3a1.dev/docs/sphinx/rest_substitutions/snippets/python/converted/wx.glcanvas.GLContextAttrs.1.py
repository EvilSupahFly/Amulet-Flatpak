    
    cxtAttrs = wx.GLContextAttrs()
    cxtAttrs.CoreProfile().OGLVersion(4, 5).Robust().ResetIsolation().EndList()
