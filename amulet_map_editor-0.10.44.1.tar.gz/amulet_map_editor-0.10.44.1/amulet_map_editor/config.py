import sys

# This will be True if "snapshot" is in the command-line arguments
snapshot = "snapshot" in sys.argv
