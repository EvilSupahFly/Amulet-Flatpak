import logging
import wx
import traceback
from OpenGL.GL import (
    glClearColor,
    glViewport,
)
import os
from typing import Optional, Generator
import weakref
import sys
import time

from minecraft_model_reader.api.resource_pack.java.download_resources import (
    get_java_vanilla_latest_iter,
    get_java_vanilla_fix,
)
from minecraft_model_reader.api.resource_pack.java import (
    JavaResourcePack,
)
from minecraft_model_reader.api.resource_pack.bedrock.download_resources import (
    get_bedrock_vanilla_latest_iter,
    get_bedrock_vanilla_fix,
)
from minecraft_model_reader.api.resource_pack.bedrock import BedrockResourcePack
from minecraft_model_reader.api.resource_pack import (
    load_resource_pack,
    load_resource_pack_manager,
)
from amulet.api.player import LOCAL_PLAYER

from amulet.api.data_types import OperationYieldType, Dimension

from amulet_map_editor import experimental_bedrock_resources
from amulet_map_editor.api.opengl.canvas import EventCanvas
from amulet_map_editor.api.opengl.resource_pack.resource_pack import OpenGLResourcePack
from amulet_map_editor.programs.edit.api.selection import (
    SelectionManager,
    SelectionHistoryManager,
)
from amulet_map_editor import lang
import amulet_map_editor.programs.edit as amulet_edit

from amulet_map_editor.api.opengl.camera import ControllableCamera
from amulet_map_editor.api.wx.util.button_input import ButtonInput
from amulet_map_editor.api.wx.util.mouse_movement import MouseMovement
from amulet_map_editor.api.wx.ui.traceback_dialog import TracebackDialog
from ..renderer import Renderer

from amulet.api.level import BaseLevel

log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

class BaseEditCanvas(EventCanvas):
    """Adds base logic for drawing everything related to the edit program to the canvas.
    All the user interaction code is implemented in ControllableEditCanvas to make them easier to read.
    """

    background_colour = (0.61, 0.70, 0.85)

    def __init__(self, parent: wx.Window, world: BaseLevel):
        super().__init__(parent)
        self._world = weakref.ref(world)

        self._selection: Optional[SelectionHistoryManager] = SelectionHistoryManager(
            SelectionManager(self)
        )
        self.world.history_manager.register(self._selection, False)

        self._camera: ControllableCamera = ControllableCamera(self)

        self._camera.move_speed = 2.0
        self._camera.rotate_speed = 2.0

        self._buttons: ButtonInput = ButtonInput(self)
        self._mouse: MouseMovement = MouseMovement(self)
        self._mouse.set_middle()

        resource_packs_dir = os.path.join(os.environ["DATA_DIR"], "resource_packs")
        readme_path = os.path.join(resource_packs_dir, "readme.txt")
        # create the resource packs location
        os.makedirs(resource_packs_dir, exist_ok=True)
        if not os.path.isfile(readme_path):
            with open(readme_path, "w") as f:
                f.write("Put the Java resource pack you want loaded in here.")

        self._renderer: Optional[Renderer] = None
        self._opengl_resource_pack = None

    def thread_setup(self) -> Generator[OperationYieldType, None, None]:
        """
        Set up objects that take a while to set up.
        All code in here must be thread safe and not touch the OpenGL state.
        """
        resource_packs_dir = os.path.join(os.environ["DATA_DIR"], "resource_packs")
        def _is_effective_pack(pack):
            """Return True if pack contains any usable files other than ignored placeholders."""
            try:
                if not pack or not getattr(pack, "valid_pack", False):
                    return False
                ignore_files = {"readme.txt", ".ds_store", "thumbs.db"}
                for entry in os.listdir(pack.root_dir):
                    if entry.lower() not in ignore_files and not entry.startswith("."):
                        return True
                log.debug(f"[PACK SKIPPED] {pack.root_dir} is empty or contains only ignored files.")
                return False
            except Exception as e:
                log.warning(f"[PACK CHECK ERROR] Failed to inspect {getattr(pack, 'root_dir', '?')}: {e}")
                return False
        try:
            entries = sorted(os.listdir(resource_packs_dir))
            raw_entries = list(os.listdir(resource_packs_dir))
            log.debug(f"[RP:USER_DIR] path={resource_packs_dir} exists={os.path.isdir(resource_packs_dir)}")
            log.debug(f"[RP:USER_DIR] os.listdir (raw)={raw_entries}")
            log.debug(f"[RP:USER_DIR] os.listdir (sorted)={entries}")
            sig = hashlib.sha1("".join(entries).encode('utf-8')).hexdigest()
            log.debug(f"[RP:USER_DIR] listing_sha1={sig}")
        except Exception as e:
            log.debug(f"[RP:USER_DIR] listing error: {e}")

        packs = []
        
        #user_packs = [
        #    load_resource_pack(os.path.join(resource_packs_dir, rp))
        #    for rp in os.listdir(resource_packs_dir)
        #    if os.path.isdir(os.path.join(resource_packs_dir, rp))
        #]
        user_packs = []
        try:
            for rp in os.listdir(resource_packs_dir):
                rp_path = os.path.join(resource_packs_dir, rp)
                if os.path.isdir(rp_path):
                    try:
                        # Count entries to detect "effectively empty" folders
                        try:
                            contents = os.listdir(rp_path)
                        except Exception:
                            contents = []
                        log.debug(f"[RP:CANDIDATE] name={rp} path={rp_path} entries={len(contents)} sample={contents[:8]}")
                        pack = load_resource_pack(rp_path)
                        # Guard: `pack` may be None on failure
                        pack_type = type(pack).__name__ if pack is not None else None
                        valid = getattr(pack, 'valid_pack', None)
                        fmt = getattr(pack, 'pack_format', None)
                        root = getattr(pack, 'root_dir', None)
                        log.debug(f"[RP:LOAD] name={rp} type={pack_type} valid={valid} format={fmt} root={root}")
                        user_packs.append(pack)
                    except Exception as e:
                        log.debug(f"[RP:LOAD:ERROR] name={rp} path={rp_path} error={e}")
        except Exception as e:
            log.debug(f"[RP:USER_DIR] iter error: {e}")
            
        if (
            self.world.level_wrapper.platform == "bedrock"
            and experimental_bedrock_resources
        ):
            packs.append(
                load_resource_pack(
                    os.path.join(
                        os.path.dirname(amulet_edit.__file__),
                        "amulet_resource_pack",
                        "bedrock",
                    )
                )
            )
            yield 0.1, lang.get(
                "program_3d_edit.canvas.downloading_bedrock_vanilla_resource_pack"
            )
            gen = get_bedrock_vanilla_latest_iter()
            try:
                while True:
                    yield next(gen) * 0.4 + 0.1
            except StopIteration as e:
                packs.append(e.value)
            yield 0.5, lang.get("program_3d_edit.canvas.loading_resource_packs")

            # Disabled user-supplied packs for Flatpak build.
            #packs += [pack for pack in user_packs if isinstance(pack, BedrockResourcePack) and _is_effective_pack(pack)]
            packs.append(get_bedrock_vanilla_fix())

            translator = self.world.translation_manager.get_version(
                "bedrock", (999, 0, 0)
            )
        else:
            packs.append(
                load_resource_pack(
                    os.path.join(
                        os.path.dirname(amulet_edit.__file__),
                        "amulet_resource_pack",
                        "java",
                    )
                )
            )
            yield 0.1, lang.get(
                "program_3d_edit.canvas.downloading_java_vanilla_resource_pack"
            )
            while True:
                gen = get_java_vanilla_latest_iter()
                try:
                    while True:
                        yield next(gen) * 0.4 + 0.1
                except StopIteration as e:
                    packs.append(e.value)
                    break
                except Exception as e:
                    if sys.platform == "darwin" and "CERTIFICATE_VERIFY_FAILED" in str(
                        e
                    ):
                        msg = lang.get(
                            "program_3d_edit.canvas.java_rp_failed_mac_certificates"
                        )
                    else:
                        msg = lang.get("program_3d_edit.canvas.java_rp_failed_default")
                    log.error(
                        msg,
                        exc_info=True,
                    )
                    wait = True
                    tb = traceback.format_exc()

                    def show_error():
                        nonlocal wait
                        try:
                            dialog = TracebackDialog(
                                self,
                                lang.get("program_3d_edit.canvas.java_rp_failed"),
                                f"{msg}\n{e}",
                                tb,
                            )
                            dialog.ShowModal()
                            dialog.Destroy()
                        finally:
                            wait = False

                    wx.CallAfter(show_error)
                    while wait:
                        time.sleep(0.1)

                    msg = wx.MessageDialog(
                        self,
                        lang.get("program_3d_edit.canvas.retry_download"),
                        style=wx.YES_NO,
                    )
                    if msg.ShowModal() == wx.ID_NO:
                        break

            yield 0.5, lang.get("program_3d_edit.canvas.loading_resource_packs")
            # Disabled user-supplied packs for Flatpak build.
            packs += [pack for pack in user_packs if isinstance(pack, JavaResourcePack) and _is_effective_pack(pack)]
            packs.append(get_java_vanilla_fix())
            log.debug(f"Disabled user-suppied texture packs for flatpak build. Packs = {packs}")

            translator = self.world.translation_manager.get_version("java", (999, 0, 0))
        try:
            pack_roots = []
            for i, p in enumerate(packs):
                try:
                    pack_roots.append(getattr(p, 'root_dir', f"<no-root-{i}>"))
                    log.debug(f"[RP:FINAL] #{i} root={pack_roots[-1]} type={type(p).__name__} valid={getattr(p,'valid_pack',None)} format={getattr(p,'pack_format',None)}")
                except Exception as e:
                    log.debug(f"[RP:FINAL] #{i} introspection error: {e}")
            sig = hashlib.sha1("".join(str(x) for x in pack_roots).encode('utf-8')).hexdigest()
            log.debug(f"[RP:FINAL] pack_roots_sha1={sig}")
        except Exception as e:
            log.debug(f"[RP:FINAL] snapshot error: {e}")
        resource_pack = load_resource_pack_manager(packs, load=False)
        for i in resource_pack.reload():
            yield i / 4 + 0.5

        self._opengl_resource_pack = OpenGLResourcePack(resource_pack, translator)

        yield 0.75, lang.get("program_3d_edit.canvas.creating_texture_atlas")
        for i in self._opengl_resource_pack.setup():
            yield i / 4 + 0.75

    def post_thread_setup(self) -> Generator[OperationYieldType, None, None]:
        """
        Any logic that needs to be run after everything has been set up.
        Code here will be run from the main thread.
        The canvas has still not been shown here so do not touch the OpenGL state. Do this in _init_opengl.
        """
        yield 1.0, lang.get("program_3d_edit.canvas.setting_up_renderer")
        self._renderer: Optional[Renderer] = Renderer(
            self,
            self.world,
            self.context_identifier,
            self._opengl_resource_pack,
        )

    def _init_opengl(self):
        super()._init_opengl()
        glClearColor(*self.background_colour, 1.0)

        try:
            player = self.world.get_player(LOCAL_PLAYER)
            location, rotation = player.location, player.rotation
            self.dimension = player.dimension
        except:
            location, rotation = (0.0, 100.0, 0.0), (45.0, 45.0)

        self._camera.location_rotation = location, rotation
        self._renderer.move_camera(location, rotation)

    def bind_events(self):
        """Set up all events required to run.
        Note this will also bind subclass events."""
        self.Bind(wx.EVT_SIZE, self._on_size)
        self.selection.bind_events()
        self.buttons.bind_events()
        self.mouse.bind_events()
        self.renderer.bind_events()

    def enable(self):
        """Enable the canvas and start it working."""
        self._opengl_canvas.SetCurrent(self._context)
        self.renderer.enable()
        self.buttons.enable()

    def disable(self):
        """Disable the canvas and unload all geometry."""
        self.renderer.disable()
        self.buttons.disable()

    def is_closeable(self):
        """Check that the canvas and contained data is safe to be closed."""
        return self.renderer.is_closeable()

    def close(self):
        """Destroy all contained data so that the window can be safely destroyed."""
        self.renderer.close()

    @property
    def world(self) -> BaseLevel:
        """The amulet-core `BaseLevel` subclass representing the "world" that is open."""
        return self._world()

    @property
    def renderer(self) -> Renderer:
        """The `Renderer` class that handles the drawable objects and draws them."""
        return self._renderer

    @property
    def dimension(self) -> Dimension:
        """The currently loaded dimension in the renderer."""
        return self.renderer.dimension

    @dimension.setter
    def dimension(self, dimension: Dimension):
        """Set the currently loaded dimension in the renderer."""
        self.renderer.dimension = dimension

    @property
    def camera(self) -> ControllableCamera:
        """A class holding the state of the camera with methods to access and modify the state."""
        return self._camera

    @property
    def buttons(self) -> ButtonInput:
        """A class that manages converting button presses into actions based on set keybinds."""
        return self._buttons

    @property
    def mouse(self) -> MouseMovement:
        """A class that manages mouse movement."""
        return self._mouse

    @property
    def selection(self) -> SelectionManager:
        """A simple class for storing the selection state."""
        return self._selection.value

    def _on_size(self, evt):
        wx.CallAfter(self._set_size)
        evt.Skip()

    def _set_size(self):
        size = self._opengl_canvas.GetClientSize() * self._opengl_canvas.GetContentScaleFactor()
        width, height = size
        self._opengl_canvas.SetCurrent(self._context)
        glViewport(0, 0, width, height)
        if height > 0:
            self.camera.aspect_ratio = width / height
        else:
            self.camera.aspect_ratio = 1
