#!/usr/bin/env python3

def _on_error(e):
    """Code to handle errors"""
    try:
        import traceback
        import sys
        import os

    except ImportError as e:
        # Something has gone seriously wrong
        print(e)
        print("Failed to import requirements. Check that you extracted correctly.")
        input("Press ENTER to continue.")
    else:
        err = "\n".join(
            [traceback.format_exc()]
            + ["Failed to import requirements. Check that you extracted correctly."]
            * isinstance(e, ImportError)
            + [str(e)]
        )
        print(err)
        try:
            with open("crash.log", "w") as f:
                f.write(err)
        except OSError:
            pass
        input("Press ENTER to continue.")
        sys.exit(1)

try:
    import sys
    import shutil
    import amulet_map_editor.config as _config
    _config.snapshot = "snapshot" in sys.argv # Added argument for using snapshots

    if sys.version_info[:2] < (3, 7):
        raise Exception("Must be using Python 3.7+")
    import logging
    import os
    import traceback
    import glob
    import time
    import wx
    import platformdirs
    from datetime import datetime

    if sys.platform == "linux" and wx.VERSION >= (4, 1, 1):
        # bug 247
        os.environ["PYOPENGL_PLATFORM"] = "egl"
except Exception as e_:
    _on_error(e_)

def _init_log():
    logs_path = os.environ["LOG_DIR"]
    # set up handlers
    os.makedirs(logs_path, exist_ok=True)
    # remove all log files older than a week
    for path in glob.glob(os.path.join(glob.escape(logs_path), "*.log")):
        if (
            os.path.isfile(path)
            and os.path.getmtime(path) < time.time() - 3600 * 24 * 7
        ):
            os.remove(path)
    
    log = logging.getLogger()
    
    debug_mode = "amulet-debug" in sys.argv
    log.setLevel(logging.DEBUG if debug_mode else logging.INFO)

    #if debug_mode:
    formatter = logging.Formatter(
        "%(asctime)s.%(msecs)03d | %(levelname)-8s | "
        "%(filename)s:%(lineno)d | %(funcName)s() | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    #else:
    #    formatter = logging.Formatter(
    #        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    #    )

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # File handler
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_handler = logging.FileHandler(os.path.join(logs_path, f"amulet_{timestamp}.log"), "w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    log.addHandler(file_handler)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    log.addHandler(console_handler)

def main():
    try:
        _init_log()
        log = logging.getLogger(__name__)
        log.setLevel(logging.DEBUG)
        # Initialise default paths.
        data_dir = platformdirs.user_data_dir("AmuletMapEditor", "AmuletTeam")
        os.environ.setdefault("DATA_DIR", data_dir)
        config_dir = platformdirs.user_config_dir("AmuletMapEditor", "AmuletTeam")
        if config_dir == data_dir:
            config_dir = os.path.join(data_dir, "Config")
        os.environ.setdefault("CONFIG_DIR", config_dir)
        cache_dir = os.environ.setdefault("CACHE_DIR", platformdirs.user_cache_dir("AmuletMapEditor", "AmuletTeam"))
        log_dir = os.environ.setdefault("LOG_DIR", platformdirs.user_log_dir("AmuletMapEditor", "AmuletTeam"))

        # Clear cache only if explicitly requested
        if "clear-cache" in sys.argv:
            log.info("Clearing cache directory...")
            if os.path.isdir(cache_dir) and os.listdir(cache_dir):
                for entry in os.listdir(cache_dir):
                    path = os.path.join(cache_dir, entry)
                    try:
                        if os.path.isfile(path) or os.path.islink(path):
                            os.remove(path)
                        elif os.path.isdir(path):
                            shutil.rmtree(path)
                    except Exception as e:
                        log.warning(f"Failed to remove {path}: {e}")
            else:
                log.info("Cache directory is already empty.")

        from amulet_map_editor.api.framework import AmuletApp

        log.debug(f"Platform Debug:")
        log.debug(f"sys.platform == {sys.platform} and wx.VERSION = ({wx.VERSION}):")
        log.debug(f"    os.environ[PYOPENGL_PLATFORM] = egl")
        log.debug(f"[amulet_map_editor/__main__.py] Path Checks:")
        log.debug(f"[data_dir] - {data_dir}")
        log.debug(f"[config_dir] - {config_dir}")
        log.debug(f"[cache_dir] - {cache_dir}")
        log.debug(f"[log_dir] - {log_dir}")
        log.debug(f"[amulet_map_editor/__main__.py] Paths confirmed.")

    except Exception as e:
        _on_error(e)
    else:
        try:
            app = AmuletApp(0)
            app.MainLoop()
        except Exception as e:
            log = logging.getLogger(__name__)
            log.critical(f"Amulet Crashed. Sorry about that. Please report it to a developer if you think this is an issue. \nCall stack:\n" + "".join(traceback.format_stack(limit=10)))
            input("Press ENTER to continue.")

    sys.exit(0)

if __name__ == "__main__":
    main()
