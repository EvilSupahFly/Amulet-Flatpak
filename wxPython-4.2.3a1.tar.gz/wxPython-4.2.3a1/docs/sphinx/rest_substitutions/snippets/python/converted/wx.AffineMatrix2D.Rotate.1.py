
            #           | cos    sin   0 |   | self.11  self.12   0 |
            # matrix' = | -sin   cos   0 | x | self.21  self.22   0 |
            #           |  0      0    1 |   | self.tx  self.ty   1 |
