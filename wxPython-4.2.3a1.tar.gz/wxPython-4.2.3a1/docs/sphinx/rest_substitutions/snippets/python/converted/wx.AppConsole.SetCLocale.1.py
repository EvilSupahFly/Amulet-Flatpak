
    setlocale(LC_ALL, "")
