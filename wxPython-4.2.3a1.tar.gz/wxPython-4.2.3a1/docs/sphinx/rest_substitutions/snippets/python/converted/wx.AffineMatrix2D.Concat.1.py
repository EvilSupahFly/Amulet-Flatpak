
            #           | t.m_11  t.m_12  0 |   | m_11  m_12   0 |
            # matrix' = | t.m_21  t.m_22  0 | x | m_21  m_22   0 |
            #           | t.m_tx  t.m_ty  1 |   | m_tx  m_ty   1 |
