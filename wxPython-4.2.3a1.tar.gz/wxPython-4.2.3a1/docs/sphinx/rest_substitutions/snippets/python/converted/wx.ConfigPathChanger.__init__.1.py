
            wx.ConfigPathChanger(wx.ConfigBase.Get(), "/MyProgram/SomeKeyName")
