
        contextHelp = wx.ContextHelp(myWindow)
