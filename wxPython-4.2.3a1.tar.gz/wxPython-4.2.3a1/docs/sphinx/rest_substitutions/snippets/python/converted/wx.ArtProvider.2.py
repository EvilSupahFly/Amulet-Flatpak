
        if wx.Platform == '__WXGTK__':
            bmp = wx.ArtProvider.GetBitmap("gtk-cdrom", wx.ART_MENU)



