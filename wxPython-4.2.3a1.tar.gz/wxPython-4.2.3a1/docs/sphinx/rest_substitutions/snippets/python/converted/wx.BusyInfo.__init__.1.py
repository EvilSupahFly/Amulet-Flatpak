    
    wait = wx.BusyInfo(wx.BusyInfoFlags().Parent(parent).Label(message))
