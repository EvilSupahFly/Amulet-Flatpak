#!/usr/bin/env python

import Main
Main.main()
