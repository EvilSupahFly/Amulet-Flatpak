#----------------------------------------------------------------------
# Name:        wx.lib.mixins
# Purpose:     A package for helpful wxPython mix-in classes
#
# Author:      Robin Dunn
#
# Created:     15-May-2001
# Copyright:   (c) 2001-2020 by Total Control Software
# Licence:     wxWindows license
#----------------------------------------------------------------------
# 12/14/2003 - Jeff Grimmett (grimmtooth@softhome.net)
#
# o 2.5 compatibility update.
#



