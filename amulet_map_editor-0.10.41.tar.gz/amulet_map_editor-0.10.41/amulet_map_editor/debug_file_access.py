import os, pathlib, traceback, builtins, logging, platformdirs, inspect, threading, traceback
print("DEBUG: debug_file_access.py this line comes after import os, pathlib, traceback, builtins, logging, platformdirs, inspect, threading, traceback is called on line 1.")
_trace_lock = threading.local()
_trace_lock_global = threading.Lock()

# Define log paths using XDG-defined directories
LOG_DIR = platformdirs.user_log_dir("AmuletMapEditor", "AmuletTeam")
os.makedirs(LOG_DIR, exist_ok=True)

ACCESS_LOG_FILE = os.path.join(LOG_DIR, "debug_file_access.log")
#RESOLVE_LOG_FILE = os.path.join(LOG_DIR, "debug_resolve_glob.log")

# Try writing initial entry
try:
    with open(ACCESS_LOG_FILE, "a") as log:
        log.write("amulet_map_editor/debug_file_access.py:L16: Debug logging initialized...\n")
except Exception as e:
    print(f"Failed to write access log: {e}")

TEXTURE_DEBUG = False  # Toggle for full texture logging
_logger_ready = False
_resolve_logger_ready = False
_monitoring_started = False
_active = False
_trace_count = 0
_trace_max = 5000

# Access logger
logger = logging.getLogger("debug_file_access")
logger.setLevel(logging.DEBUG)

# Resolve/glob logger
resolve_logger = logging.getLogger("debug_resolve_glob")
resolve_logger.setLevel(logging.DEBUG)

def log_traceback(path, success=True, error_msg=None):
    global _trace_count, ACCESS_LOG_FILE #, RESOLVE_LOG_FILE

    path_str = str(path).lower()
    dbg_keywords = ["water", "lava"]
    excluded_folders = ["particles", "mob_effect", "item", "painting", "misc", "items", "gui"]

    if not TEXTURE_DEBUG:
        if not any(k in path_str for k in dbg_keywords):
            return
        if any(f"/{f}/" in path_str for f in excluded_folders):
            return

    with _trace_lock_global:
        if _trace_count > _trace_max:
            print(f"DEBUG: log_traceback skipped (max trace count {_trace_max})")
            return

    if getattr(_trace_lock, "active", False):
        return  # prevent recursion

    _trace_lock.active = True
    try:
        # Raw fallback log write
        try:
            with open(ACCESS_LOG_FILE, "a", encoding="utf-8") as f:
                f.write("===\n")
                status = "SUCCESS" if success else f"FAILED ({error_msg})"
                f.write(f"{status}: {path}\n")
                traceback.print_stack(file=f)
        except Exception as e:
            print(f"DEBUG: failed to write to ACCESS_LOG_FILE: {e}")

        # Logging if ready
        if _logger_ready:
            trace = "".join(traceback.format_stack(limit=6))
            status = "SUCCESS" if success else f"FAILED ({error_msg})"
            action = inspect.stack()[1].function
            logger.debug(f"[{action.upper()} - {status}] {path}\nTraceback:\n{trace}")
            print(f"DEBUG: logger.debug written to {ACCESS_LOG_FILE}")
        else:
            print("DEBUG: logger not ready, skipping logger.debug")

        _trace_count += 1
    finally:
        _trace_lock.active = False
        
def log_resolve_traceback(path, success=True, error_msg=None):
    #print("DEBUG: log_resolve_traceback called")
    if not _resolve_logger_ready:
        #print("DEBUG: resolve_logger not ready")
        return
    #print("DEBUG: resolve_logger ready")
    trace = "".join(traceback.format_stack(limit=6))
    status = "SUCCESS" if success else f"FAILED ({error_msg})"
    resolve_logger.debug(f"[RESOLVE - {status}] {path}\nTraceback:\n{trace}")

# Wrap built-ins
original_open = builtins.open
def open_wrapper(file, mode="r", *args, **kwargs):
    #print("DEBUG: open_wrapper called")
    try:
        result = original_open(file, mode, *args, **kwargs)
        log_traceback(file, success=True)
        return result
    except Exception as e:
        log_traceback(file, success=False, error_msg=str(e))
        raise

original_exists = os.path.exists
def exists_wrapper(path):
    #print("DEBUG: exists_wrapper called")
    try:
        result = original_exists(path)
        log_traceback(path, success=True)
        return result
    except Exception as e:
        log_traceback(path, success=False, error_msg=str(e))
        raise

original_listdir = os.listdir
def listdir_wrapper(path):
    #print("DEBUG: listdir_wrapper called")
    try:
        result = original_listdir(path)
        log_traceback(path, success=True)
        return result
    except Exception as e:
        log_traceback(path, success=False, error_msg=str(e))
        raise

original_path_open = pathlib.Path.open
def path_open_wrapper(self, *args, **kwargs):
    #print("DEBUG: path_open_wrapper called")
    try:
        result = original_path_open(self, *args, **kwargs)
        log_traceback(self, success=True)
        return result
    except Exception as e:
        log_traceback(self, success=False, error_msg=str(e))
        raise

original_isfile = os.path.isfile
def isfile_wrapper(path):
    #print("DEBUG: isfile_wrapper called")
    try:
        result = original_isfile(path)
        log_traceback(path, success=True)
        return result
    except Exception as e:
        log_traceback(path, success=False, error_msg=str(e))
        raise

original_isdir = os.path.isdir
def isdir_wrapper(path):
    #print("DEBUG: isdir_wrapper called")
    try:
        result = original_isdir(path)
        log_traceback(path, success=True)
        return result
    except Exception as e:
        log_traceback(path, success=False, error_msg=str(e))
        raise

# Wrap .resolve()
original_resolve = pathlib.Path.resolve
def resolve_wrapper(self, *args, **kwargs):
    #print("DEBUG: resolve_wrapper called")
    try:
        result = original_resolve(self, *args, **kwargs)
        log_resolve_traceback(result, success=True)
        return result
    except Exception as e:
        log_resolve_traceback(self, success=False, error_msg=str(e))
        raise

# Wrap .glob()
original_glob = pathlib.Path.glob
def glob_wrapper(self, pattern):
    #print("DEBUG: glob_wrapper called")
    try:
        result = list(original_glob(self, pattern))  # Force iteration for logging
        for p in result:
            log_resolve_traceback(p, success=True)
        return iter(result)
    except Exception as e:
        log_resolve_traceback(self, success=False, error_msg=str(e))
        raise

def start_monitoring():
    import traceback
    """Start monitoring file access and path resolution."""
    print("amulet_map_editor/debug_file_access.py:L186: DEBUG: start_monitoring called")
    global _logger_ready, _resolve_logger_ready, _monitoring_started, ACCESS_LOG_FILE, _active
    logger.debug("start_monitoring stack:\n" + "".join(traceback.format_stack()))

#    if _monitoring_started:
#        return
#    _monitoring_started = True
#
#    if not _logger_ready or getattr(log_traceback, "_active", False):
#        return
#    log_traceback._active = True
#    
#    try:
#        file_handler = logging.FileHandler(ACCESS_LOG_FILE, "w", encoding="utf-8")
#        file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s\n"))
#        logger.addHandler(file_handler)
#        _logger_ready = True
#    finally:
#        log_traceback._active = False

    #if not _resolve_logger_ready:
    #    resolve_handler = logging.FileHandler(RESOLVE_LOG_FILE, "w", encoding="utf-8")
    #    resolve_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s\n"))
    #    resolve_logger.addHandler(resolve_handler)
    #    _resolve_logger_ready = True
#    """Decided not to use resolve_logger for now"""
#
#    logger.info("File access monitoring enabled.")
    #resolve_logger.info("Path resolve/glob monitoring enabled.")

    if _active:
        logger.debug("start_monitoring: already active. Skipping re-wrap.")
        return

    if not _logger_ready:
        _logger_ready = True  # if not yet ready, set it now
        logger.debug("start_monitoring: setting _logger_ready to True")

    log_traceback._active = True
    try:
        try:
            print(f"DEBUG: ACCESS_LOG_FILE is {ACCESS_LOG_FILE}")

            file_handler = logging.FileHandler(ACCESS_LOG_FILE, "w", encoding="utf-8")
            print("DEBUG: FileHandler created successfully")

            file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s\n"))
            print("DEBUG: Formatter set successfully")

            logger.addHandler(file_handler)
            print("DEBUG: Handler added to logger successfully")

            _logger_ready = True
            _active = True
            print("DEBUG: _logger_ready set to True")

        except Exception as inner_e:
            print(f"DEBUG: Exception inside FileHandler setup: {inner_e}")
            import traceback
            traceback.print_exc()

    finally:
        log_traceback._active = False
        print("DEBUG: start_monitoring finally block complete")

    print(f"DEBUG: logger.handlers = {logger.handlers}")
    print("DEBUG: start_monitoring completed")
    
    # Apply wrappers
    builtins.open = open_wrapper
    os.path.exists = exists_wrapper
    os.listdir = listdir_wrapper
    pathlib.Path.open = path_open_wrapper
    os.path.isfile = isfile_wrapper
    os.path.isdir = isdir_wrapper
    pathlib.Path.resolve = resolve_wrapper
    pathlib.Path.glob = glob_wrapper

    # Enable monitoring automatically when the module is imported    
    #logger.info(f"amulet_map_editor/debug_file_access.py: File access logging started. \nAccess Log file: {ACCESS_LOG_FILE}\nResolve Log file: {RESOLVE_LOG_FILE}")
    logger.info(f"amulet_map_editor/debug_file_access.py: File access logging started. \nAccess Log file: {ACCESS_LOG_FILE}")
    logger.info("amulet_map_editor/debug_file_access.py: debug_file_access successfully imported and executing.")
    logger.info(f"amulet_map_editor/debug_file_access.py: open is wrapped: {open is open_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: os.path.exists is wrapped: {os.path.exists is exists_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: os.listdir is wrapped: {os.listdir is listdir_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: pathlib.Path.open is wrapped: {pathlib.Path.open is path_open_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: os.path.isfile is wrapped: {os.path.isfile is isfile_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: os.path.isdir is wrapped: {os.path.isdir is isdir_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: pathlib.Path.resolve is wrapped: {pathlib.Path.resolve is resolve_wrapper}")
    logger.info(f"amulet_map_editor/debug_file_access.py: pathlib.Path.glob is wrapped: {pathlib.Path.glob is glob_wrapper}")

start_monitoring()
print("DEBUG: debug_file_access.py this line comes after start_monitoring() is called on line 276.")

if __name__ == "__main__":
    print("degug_file_access.py:L242: Running debug_file_access directly...")
    start_monitoring()
    open(__file__).read()  # Should trigger logging